g++ main.cpp ColorScale.cpp Sky.cpp DisplayManager.cpp AppManager.cpp -lsfml-window -lsfml-graphics -lsfml-system
./a.out
