#include "DisplayManager.hpp"

sf::RenderWindow DisplayManager::app(sf::VideoMode(1000,800),"Tets");
