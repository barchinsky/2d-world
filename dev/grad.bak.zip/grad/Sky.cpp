#include "Sky.hpp"
#include "LOG.hpp"

Sky::Sky(int _size)
{
    size = _size;
   /* mColUp.set(50,50,150,150);
    mColDown.set(100,50,100,150);
    tab = new sf::Color[size];
    insertGrad();*/
    Init();
}

void Sky::Init()
{
    mColUp.set(0,0,0,0);
    mColDown.set(0,0,100,255);
    tab = new sf::Color[size];
    //this->insertGrad();
}

Sky::~Sky()
{
    delete[] tab;
}

void Sky::update()
{
    mColUp.set(appManager.getTimeDiff(),mColUp.g+1,mColUp.b+3,appManager.getTimeDiff());
    
    LOG(mColUp.r);
    
    insertGrad();
    DisplayManager().getWindow().draw(sprite);
}

void Sky::insertGrad()
{
    gradient.insert(1.0,sf::Color(mColUp.r,mColUp.g,mColUp.b,mColUp.a));
    gradient.insert(2.0,sf::Color(mColDown.r,mColDown.g,mColDown.b,mColDown.a));

    gradient.fillTab(tab,size);
    img.create(size,size);

    this->fillTab();
    texture.loadFromImage(img);
    sprite = sf::Sprite(texture);

}

void Sky::proceedUp()
{}

void Sky::proceedDown()
{}

void Sky::fillTab()
{
    for(int i=0; i<size; ++i)
    {
        for(int j=0; j<size; ++j)
        {
            img.setPixel(i,j,this->tab[j]);
        }
    }

}
